﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Replacements
{
    class Days
    {
        //Copyright(C) 2019 Евгений Петриев
        //This program is free software: you can redistribute it and/or modify
        //it under the terms of the GNU General Public License as published by
        //the Free Software Foundation, either version 3 of the License, or
        //(at your option) any later version.

        //This program is distributed in the hope that it will be useful,
        //but WITHOUT ANY WARRANTY; without even the implied warranty of
        //MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
        //GNU General Public License for more details.

        //You should have received a copy of the GNU General Public License
        //along with this program.If not, see<http://www.gnu.org/licenses/>.

        public static void DaysInWeek(int i, int y, out int j)
        {
            
            int l = 0;
            switch (i)
            {
                case 1:
                    l = 31;
                    break;
                case 2:
                    if((y-2000)%4 == 0)
                    {
                        l = 29;
                    }
                    else
                    {
                        l = 28;
                    }
                    break;
                case 3:
                    l = 31;
                    break;
                case 4:
                    l = 30;
                    break;
                case 5:
                    l = 31;
                    break;
                case 6:
                    l = 30;
                    break;
                case 7:
                    l = 31;
                    break;
                case 8:
                    l = 31;
                    break;
                case 9:
                    l = 30;
                    break;
                case 10:
                    l = 31;
                    break;
                case 11:
                    l = 30;
                    break;
                case 12:
                    l = 31;
                    break;
            }
            j = l;
        }
    }
}
