﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Data.SqlClient;

namespace Replacements
{
    public partial class Form1 : Form
    {
        //Copyright(C) 2019 Евгений Петриев
        //This program is free software: you can redistribute it and/or modify
        //it under the terms of the GNU General Public License as published by
        //the Free Software Foundation, either version 3 of the License, or
        //(at your option) any later version.

        //This program is distributed in the hope that it will be useful,
        //but WITHOUT ANY WARRANTY; without even the implied warranty of
        //MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
        //GNU General Public License for more details.

        //You should have received a copy of the GNU General Public License
        //along with this program.If not, see<http://www.gnu.org/licenses/>.

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CodePass.Pass(textBox2.Text, out string passGot);
            //Авторизация
            SqlCommand Login = new SqlCommand("SELECT * FROM Users WHERE (Login=@Login OR Mail=@Login) AND Password=@Password", Connections.sqlConnection);

            Login.Parameters.AddWithValue("Login", textBox1.Text);
            Login.Parameters.AddWithValue("Password", passGot);

            if (Login.ExecuteScalar() != null)
            {
                SqlDataReader reader = Login.ExecuteReader();

                while (reader.Read())
                {
                    string Nick = string.Empty;
                    string Rules = string.Empty;
                    string Password = string.Empty;
                    string Mail = string.Empty;
                    string Active_Mail = string.Empty;

                    Nick += reader["Login"];
                    Rules += reader["Rules"];
                    Password += reader["Password"];
                    Mail += reader["Mail"];
                    Active_Mail += reader["Activ_Mail"];

                    User_Log.Nick = Nick;
                    User_Log.Rules = Rules;
                    User_Log.Password = Password;
                    User_Log.Mail = Mail;
                    User_Log.Active_Mail = Active_Mail;
                }
                reader.Close();

                if(User_Log.Rules == "User") /*Панель пользователя*/
                {
                    Hide();
                    Form3 form3 = new Form3();
                    form3.ShowDialog();   
                }
                if (User_Log.Rules == "Admin") /*Панель администратора*/
                {
                    Hide();
                    Form12 form12 = new Form12();
                    form12.ShowDialog();
                }
                if (User_Log.Rules == "Content") /*Контент панель*/
                {
                    Hide();
                    Form9 form9 = new Form9();
                    form9.ShowDialog();
                }
            }
            else
            {
                label3.Visible = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            label3.Visible = false;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            label3.Visible = false;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            label3.Visible = false;
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
        }
    }
}
