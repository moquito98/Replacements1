﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Replacements
{
    public partial class Form11 : Form
    {
        //Copyright(C) 2019 Евгений Петриев
        //This program is free software: you can redistribute it and/or modify
        //it under the terms of the GNU General Public License as published by
        //the Free Software Foundation, either version 3 of the License, or
        //(at your option) any later version.

        //This program is distributed in the hope that it will be useful,
        //but WITHOUT ANY WARRANTY; without even the implied warranty of
        //MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
        //GNU General Public License for more details.

        //You should have received a copy of the GNU General Public License
        //along with this program.If not, see<http://www.gnu.org/licenses/>.
        public Form11()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand updUser = new SqlCommand("UPDATE Users SET Login=@Login, Password=@Password, Rules=@Rules, Mail=@Mail, Activ_Mail=@Activ_Mail WHERE Login=@Login1", Connections.sqlConnection);
            updUser.Parameters.AddWithValue("Login1", Info.info);
            updUser.Parameters.AddWithValue("Login", textBox1.Text);
            updUser.Parameters.AddWithValue("Password", textBox2.Text);
            updUser.Parameters.AddWithValue("Rules", comboBox1.Text);
            updUser.Parameters.AddWithValue("Mail", textBox3.Text);
            updUser.Parameters.AddWithValue("Activ_Mail", comboBox2.Text);
            updUser.ExecuteNonQuery();

            MessageBox.Show("Пользователь был успешно изменён", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Form11_Load(object sender, EventArgs e)
        {
            SqlCommand selUpdUser = new SqlCommand("SELECT * FROM Users WHERE Login=@Login", Connections.sqlConnection);
            selUpdUser.Parameters.AddWithValue("Login", Info.info);

            SqlDataReader selUpdUserReader = selUpdUser.ExecuteReader();
            while (selUpdUserReader.Read())
            {
                string Login = string.Empty;
                string Pass = string.Empty;
                string Rules = string.Empty;
                string Mail = string.Empty;
                string Active = string.Empty;

                Login += selUpdUserReader["Login"];
                Pass += selUpdUserReader["Password"];
                Rules += selUpdUserReader["Rules"];
                Mail += selUpdUserReader["Mail"];
                Active += selUpdUserReader["Activ_Mail"];

                textBox1.Text = Login;
                textBox2.Text = Pass;
                comboBox1.Text = Rules;
                textBox3.Text = Mail;
                comboBox2.Text = Active;
            }
            selUpdUserReader.Close();
        }
    }
}
