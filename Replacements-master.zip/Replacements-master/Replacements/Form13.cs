﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Replacements
{
    public partial class Form13 : Form
    {
        //Copyright(C) 2019 Евгений Петриев
        //This program is free software: you can redistribute it and/or modify
        //it under the terms of the GNU General Public License as published by
        //the Free Software Foundation, either version 3 of the License, or
        //(at your option) any later version.

        //This program is distributed in the hope that it will be useful,
        //but WITHOUT ANY WARRANTY; without even the implied warranty of
        //MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
        //GNU General Public License for more details.

        //You should have received a copy of the GNU General Public License
        //along with this program.If not, see<http://www.gnu.org/licenses/>.
        public Form13()
        {
            InitializeComponent();
        }

        private void groupsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.groupsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.zamenyDataSet1);

        }

        private void Form13_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "u0686611_ReplacementsDataSet.Groups". При необходимости она может быть перемещена или удалена.
            this.groupsTableAdapter1.Fill(this.u0686611_ReplacementsDataSet.Groups);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand insGroup = new SqlCommand("INSERT INTO Groups (Group_Name) VALUES (@Group_Name)", Connections.sqlConnection);
            insGroup.Parameters.AddWithValue("Group_Name", textBox1.Text);
            insGroup.ExecuteNonQuery();
            textBox1.Text = "";
            MessageBox.Show("Группа была успешно добавлена", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.groupsTableAdapter1.Fill(this.u0686611_ReplacementsDataSet.Groups);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int a = groupsDataGridView.SelectedCells[0].RowIndex;
            string delGroup = Convert.ToString(groupsDataGridView.Rows[a].Cells[0].Value);

            DialogResult result = MessageBox.Show("Вы уверенны, что хотите удалить группу?", "Подтвердите действие", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                SqlCommand delGr = new SqlCommand("DELETE FROM Groups WHERE Group_Name=@Group_Name", Connections.sqlConnection);
                delGr.Parameters.AddWithValue("Group_Name", delGroup);
                delGr.ExecuteNonQuery();

                this.groupsTableAdapter.Fill(this.zamenyDataSet1.Groups);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.groupsTableAdapter1.Fill(this.u0686611_ReplacementsDataSet.Groups);
        }
    }
}
