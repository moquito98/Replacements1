﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
using System.IO;
using System.Net;
using System.Data.SqlClient;

namespace Replacements
{
    public partial class Form14 : Form
    {
        //Copyright(C) 2019 Евгений Петриев
        //This program is free software: you can redistribute it and/or modify
        //it under the terms of the GNU General Public License as published by
        //the Free Software Foundation, either version 3 of the License, or
        //(at your option) any later version.

        //This program is distributed in the hope that it will be useful,
        //but WITHOUT ANY WARRANTY; without even the implied warranty of
        //MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
        //GNU General Public License for more details.

        //You should have received a copy of the GNU General Public License
        //along with this program.If not, see<http://www.gnu.org/licenses/>.

        string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        string Code = "";
        public Form14()
        {
            InitializeComponent();
        }

        private void Form14_Load(object sender, EventArgs e)
        {
            button1.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand delCode = new SqlCommand("DELETE FROM Registr_Mail WHERE Mail=@Mail", Connections.sqlConnection);
            delCode.Parameters.AddWithValue("Mail", User_Log.Mail);
            delCode.ExecuteNonQuery();

            Code = "";
            Random random = new Random();
            for (int i = 0; i < 5; i++)
            {
                int j = random.Next(0, chars.Length - 1);
                Code += chars[j];
            }

            // отправитель - устанавливаем адрес и отображаемое в письме имя
            MailAddress from = new MailAddress("replacementsmqt@gmail.com", "Replacements");
            // кому отправляем      
            MailAddress to = new MailAddress(User_Log.Mail);
            // создаем объект сообщения
            MailMessage m = new MailMessage(from, to);
            // тема письма
            m.Subject = "Подтверждение E-Mail адреса";
            // текст письма
            m.Body = "<h2>Ваш код подтверждения:"+Code+"</h2>";
            // письмо представляет код html
            m.IsBodyHtml = true;
            // адрес smtp-сервера и порт, с которого будем отправлять письмо
            SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
            // логин и пароль
            smtp.Credentials = new NetworkCredential("replacementsmqt@gmail.com", "Motherlode20");
            smtp.EnableSsl = true;
            try
            {
                smtp.Send(m);
                SqlCommand insCode = new SqlCommand("INSERT INTO Registr_Mail (Mail, Code) VALUES (@Mail, @Code)", Connections.sqlConnection);
                insCode.Parameters.AddWithValue("Mail", User_Log.Mail);
                insCode.Parameters.AddWithValue("Code", Code);
                insCode.ExecuteNonQuery();
                MessageBox.Show("Проверьте вашу электронную почту", "Активация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                button1.Enabled = false;
                TimerOtpr.StartTimer(label1, timer1, 00, 1, button1);
            }
            catch
            {
                MessageBox.Show("Проверьте интернет соединение", "Активация", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlCommand selCode = new SqlCommand("SELECT Mail FROM Registr_Mail WHERE Mail=@Mail AND Code=@Code", Connections.sqlConnection);
            selCode.Parameters.AddWithValue("Mail", User_Log.Mail);
            selCode.Parameters.AddWithValue("Code", textBox1.Text.ToUpper());

            if(selCode.ExecuteScalar() != null)
            {
                SqlCommand updUser = new SqlCommand("UPDATE Users SET Activ_Mail=@Activ_Mail WHERE Mail=@Mail", Connections.sqlConnection);
                updUser.Parameters.AddWithValue("Activ_Mail", "Active");
                updUser.Parameters.AddWithValue("Mail", User_Log.Mail);
                updUser.ExecuteScalar();
                MessageBox.Show("Ваш E-Mail успешно подтверждён", "Активация", MessageBoxButtons.OK, MessageBoxIcon.Information);

                SqlCommand selUser = new SqlCommand("SELECT Activ_Mail FROM Users WHERE Login=@Login", Connections.sqlConnection);
                selUser.Parameters.AddWithValue("Login", User_Log.Nick);
                User_Log.Active_Mail = selUser.ExecuteScalar().ToString();

                SqlCommand delCode = new SqlCommand("DELETE FROM Registr_Mail WHERE Mail=@Mail", Connections.sqlConnection);
                delCode.Parameters.AddWithValue("Mail", User_Log.Mail);
                delCode.ExecuteNonQuery();
                SqlCommand delChange = new SqlCommand("DELETE FROM Change_Password WHERE Mail=@Mail", Connections.sqlConnection);
                delChange.Parameters.AddWithValue("Mail", User_Log.Mail);
                delChange.ExecuteNonQuery();
                textBox1.Clear();
                Form8 form8 = new Form8();
                form8.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Неверный код", "Активация", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
