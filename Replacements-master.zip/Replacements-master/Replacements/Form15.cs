﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
using System.IO;
using System.Net;
using System.Data.SqlClient;

namespace Replacements
{
    public partial class Form15 : Form
    {
        //Copyright(C) 2019 Евгений Петриев
        //This program is free software: you can redistribute it and/or modify
        //it under the terms of the GNU General Public License as published by
        //the Free Software Foundation, either version 3 of the License, or
        //(at your option) any later version.

        //This program is distributed in the hope that it will be useful,
        //but WITHOUT ANY WARRANTY; without even the implied warranty of
        //MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
        //GNU General Public License for more details.

        //You should have received a copy of the GNU General Public License
        //along with this program.If not, see<http://www.gnu.org/licenses/>.

        string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        string Code = "";
        public Form15()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand delCode = new SqlCommand("DELETE FROM Change_Password WHERE Mail=@Mail", Connections.sqlConnection);
            delCode.Parameters.AddWithValue("Mail", User_Log.Mail);
            delCode.ExecuteNonQuery();

            Code = "";
            Random random = new Random();
            for (int i = 0; i < 5; i++)
            {
                int j = random.Next(0, chars.Length - 1);
                Code += chars[j];
            }

            // отправитель - устанавливаем адрес и отображаемое в письме имя
            MailAddress from = new MailAddress("replacementsmqt@gmail.com", "Replacements");
            // кому отправляем      
            MailAddress to = new MailAddress(User_Log.Mail);
            // создаем объект сообщения
            MailMessage m = new MailMessage(from, to);
            // тема письма
            m.Subject = "Смена пароля";
            // текст письма
            m.Body = "<h2>Ваш код для смены пароля:" + Code + "</h2>";
            // письмо представляет код html
            m.IsBodyHtml = true;
            // адрес smtp-сервера и порт, с которого будем отправлять письмо
            SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
            // логин и пароль
            smtp.Credentials = new NetworkCredential("replacementsmqt@gmail.com", "Motherlode20");
            smtp.EnableSsl = true;
            try
            {
                smtp.Send(m);
                SqlCommand insCode = new SqlCommand("INSERT INTO Change_Password (Mail, Code) VALUES (@Mail, @Code)", Connections.sqlConnection);
                insCode.Parameters.AddWithValue("Mail", User_Log.Mail);
                insCode.Parameters.AddWithValue("Code", Code);
                insCode.ExecuteNonQuery();
                MessageBox.Show("Проверьте вашу электронную почту", "Активация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                button1.Enabled = false;
                TimerOtpr.StartTimer(label1, timer1, 00, 1, button1);
            }
            catch
            {
                MessageBox.Show("Проверьте интернет соединение", "Активация", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string[] symbols = new string[] { "#", "@", "*", ":", "/", "+" };
            bool check = false;
            SqlCommand selPass = new SqlCommand("SELECT Password FROM Users WHERE Login=@Login", Connections.sqlConnection);
            selPass.Parameters.AddWithValue("Login", User_Log.Nick);
            string pass = selPass.ExecuteScalar().ToString();
            string passI = "";
            for(int i = 0; i != pass.Length; i++)
            {
                if(i %2 == 0)
                {
                    passI += pass[i];
                }
            }
            for (int i = 0; i <= textBox2.Text.Length - 1; i++)
            {
                for (int j = 0; j != 6; j++)
                {
                    if (textBox2.Text[i].ToString() == symbols[j])
                    {
                        check = true;
                        MessageBox.Show("Символы #,@,*,:,/,+ запрещены при вводе пароля", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            if (pass.Length < 4)
            {
                check = true;
                MessageBox.Show("Пароль должен содержать минимум 4 символа", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (textBox2.Text == passI)
            {
                check = true;
                MessageBox.Show("Ваш пароль совпадает с вашим старым паролем", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if(textBox2.Text != textBox3.Text)
            {
                check = true;
                MessageBox.Show("Пароли не совпадают", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            SqlCommand selCode = new SqlCommand("SELECT Code FROM Change_Password WHERE Mail=@Mail AND Code=@Code", Connections.sqlConnection);
            selCode.Parameters.AddWithValue("Mail", User_Log.Mail);
            selCode.Parameters.AddWithValue("Code", textBox1.Text.ToUpper());
            if(selCode.ExecuteScalar() != null && check == false)
            {
                TextBox[] textBoxes = new TextBox[] { textBox1, textBox2, textBox3 };
                CodePass.Pass(textBox2.Text, out string passGot);
                SqlCommand updUser = new SqlCommand("UPDATE Users SET Password=@Password WHERE Login=@Login", Connections.sqlConnection);
                updUser.Parameters.AddWithValue("Password", passGot);
                updUser.Parameters.AddWithValue("Login", User_Log.Nick);
                updUser.ExecuteNonQuery();
                MessageBox.Show("Ваш пароль успешно изменён", "Смена пароля", MessageBoxButtons.OK, MessageBoxIcon.Information);
                for(int i = 0; i != 3; i++)
                {
                    textBoxes[i].Clear();
                }
                Form8 form8 = new Form8();
                form8.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Неверный код подтверждения", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}