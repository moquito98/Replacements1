﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Replacements
{
    public partial class Form2 : Form
    {
        //Copyright(C) 2019 Евгений Петриев
        //This program is free software: you can redistribute it and/or modify
        //it under the terms of the GNU General Public License as published by
        //the Free Software Foundation, either version 3 of the License, or
        //(at your option) any later version.

        //This program is distributed in the hope that it will be useful,
        //but WITHOUT ANY WARRANTY; without even the implied warranty of
        //MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
        //GNU General Public License for more details.

        //You should have received a copy of the GNU General Public License
        //along with this program.If not, see<http://www.gnu.org/licenses/>.
        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            label4.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] symbols = new string[] { "#", "@", "*", ":", "/", "+" };
            bool check = false;

            SqlCommand Reg = new SqlCommand("SELECT * FROM Users WHERE Login=@Login OR Mail=@mail", Connections.sqlConnection); /*Проверка на занятость ника или e-mailа*/

            Reg.Parameters.AddWithValue("Login", textBox1.Text);
            Reg.Parameters.AddWithValue("Mail", textBox3.Text);

            string pass = textBox2.Text;

            if(textBox1.Text.Length < 4)
            {
                check = true;
                label4.Text = "Логин должен содержать как минимум 4 символа";
                label4.Visible = true;
            }
            if(pass.Length < 4)
            {
                check = true;
                label4.Text = "Пароль должен содержать минимум 4 символа";
                label4.Visible = true;
            }
            for(int i = 0; i <= pass.Length-1; i++)
            {
                for(int j = 0; j !=6; j++)
                {
                    if(pass[i].ToString() == symbols[j])
                    {
                        check = true;
                        label4.Text = "Символы #,@,*,:,/,+ запрещены при вводе пароля";
                        label4.Visible = true;
                    }
                }
            }
            if (Reg.ExecuteScalar() != null)
            {
                label4.Text = "Этот логин/e-mail уже занят";
                label4.Visible = true;
                check = true;
            }
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
            {
                label4.Text = "Все поля должны быть заполнены";
                label4.Visible = true;
                check = true;  
            }
            if (check != true)
            {
                CodePass.Pass(textBox2.Text, out string passGot);
                //Добавление нового пользователя
                SqlCommand Regist = new SqlCommand("INSERT INTO Users (Login, Password, Rules, Mail, Activ_Mail) VALUES (@Login, @Password, 'User', @Mail, 'Non active')", Connections.sqlConnection);
                Regist.Parameters.AddWithValue("Login", textBox1.Text);
                Regist.Parameters.AddWithValue("Password", passGot);
                Regist.Parameters.AddWithValue("Mail", textBox3.Text);

                Regist.ExecuteNonQuery();

                MessageBox.Show("Вы были успешно зарегестрированы", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Close();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            label4.Visible = false;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            label4.Visible = false;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            label4.Visible = false;
        }
    }
}
