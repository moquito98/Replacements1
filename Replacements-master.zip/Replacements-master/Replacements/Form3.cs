﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
using System.Diagnostics;

namespace Replacements
{
    public partial class Form3 : Form
    {
        //Copyright(C) 2019 Евгений Петриев
        //This program is free software: you can redistribute it and/or modify
        //it under the terms of the GNU General Public License as published by
        //the Free Software Foundation, either version 3 of the License, or
        //(at your option) any later version.

        //This program is distributed in the hope that it will be useful,
        //but WITHOUT ANY WARRANTY; without even the implied warranty of
        //MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
        //GNU General Public License for more details.

        //You should have received a copy of the GNU General Public License
        //along with this program.If not, see<http://www.gnu.org/licenses/>.


        Label[] labels = new Label[6];
        string chislznam = string.Empty;
        string[] chas = new string[6];
        int indexday = 0;
        bool check = false;
        string zan = string.Empty;
        string zan_izm = string.Empty;
        int length = 0;

        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            Connections.Connect();
            this.Text = "Replacements " + Version.version;

            if(Connections.checkConnect == true)
            {
                SqlCommand Update = new SqlCommand("SELECT Link FROM Version WHERE Last_Version<>@Last_Version", Connections.sqlConnection);
                Update.Parameters.AddWithValue("Last_Version", Version.version);
                if (Update.ExecuteScalar() != null)
                {
                    DialogResult result = MessageBox.Show("Вышла новая версия, хотите её скачать?", "Новая версия", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                    if (result == DialogResult.Yes)
                    {
                        Process.Start(Update.ExecuteScalar().ToString());
                    }
                }
            }

            labels[0] = label14;
            labels[1] = label13;
            labels[2] = label12;
            labels[3] = label11;
            labels[4] = label4;
            labels[5] = label3;

            chas[0] = "1-2";
            chas[1] = "3-4";
            chas[2] = "5-6";
            chas[3] = "7-8";
            chas[4] = "9-10";
            chas[5] = "11-12";

            if (Connections.checkConnect == true)
            {
                SqlCommand groups = new SqlCommand("SELECT * FROM Groups", Connections.sqlConnection); /*Добавление групп в comboBox*/
                SqlDataReader readerGroup = groups.ExecuteReader();
                while (readerGroup.Read())
                {
                    comboBox1.Items.Add(readerGroup["Group_Name"]);
                }
                readerGroup.Close();

                indexday = Convert.ToInt32(dateTimePicker1.Value.DayOfWeek);
            }
            else
            {
                comboBox1.Enabled = false;
                dateTimePicker1.Enabled = false;
                button1.Enabled = false;
            }
            if(User_Log.Nick != "")
            {
                button3.Visible = true;
                button1.Visible = false;
                label15.Visible = true;
                button4.Visible = true;
                label15.Text = "Вы вошли как " + User_Log.Nick;
            }
            else
            {
                button3.Visible = false;
                button1.Visible = true;
                label15.Visible = false;
                button4.Visible = false;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlCommand c_z = new SqlCommand("SELECT Chisl_Znam FROM Chisl_Znam WHERE Po>=@date AND S<=@date", Connections.sqlConnection); /*Выборка числителя/занаменателя*/
            c_z.Parameters.AddWithValue("date", Convert.ToDateTime(dateTimePicker1.Value).Date);
            try
            {
                chislznam = c_z.ExecuteScalar().ToString();
            }
            catch
            {
                check = true;
            }
            indexday = Convert.ToInt32(dateTimePicker1.Value.DayOfWeek);
            if (check == false && comboBox1.Text != "")
            {
                for (int i = 0; i < 6; i++)
                {
                    SqlCommand osn_rasp = new SqlCommand("SELECT Name_Zan FROM Osn_Rasp WHERE Day_of_Week=@Day_of_Week AND Chas=@Chas AND Name_Grup=@Name_Grup AND Chisl_Znam=@Chisl_Znam", Connections.sqlConnection);
                    osn_rasp.Parameters.AddWithValue("Day_of_Week", indexday);
                    osn_rasp.Parameters.AddWithValue("Chas", chas[i]);
                    osn_rasp.Parameters.AddWithValue("Name_Grup", comboBox1.Text);
                    osn_rasp.Parameters.AddWithValue("Chisl_Znam", "Числитель");

                    SqlCommand zam = new SqlCommand("SELECT Name_Zan FROM Zameni WHERE Name_Group=@Name_Group AND Date=@Date AND Chas=@Chas", Connections.sqlConnection);
                    zam.Parameters.AddWithValue("Name_Group", comboBox1.Text);
                    zam.Parameters.AddWithValue("Date", Convert.ToDateTime(dateTimePicker1.Value).Date);
                    zam.Parameters.AddWithValue("Chas", chas[i]);

                    SqlCommand osn_rasp_znam = new SqlCommand("SELECT Name_Zan FROM Osn_Rasp WHERE Day_of_Week=@Day_of_Week AND Chas=@Chas AND Name_Grup=@Name_Grup AND Chisl_Znam=@Chisl_Znam", Connections.sqlConnection);
                    osn_rasp_znam.Parameters.AddWithValue("Day_of_Week", indexday);
                    osn_rasp_znam.Parameters.AddWithValue("Chas", chas[i]);
                    osn_rasp_znam.Parameters.AddWithValue("Name_Grup", comboBox1.Text);
                    osn_rasp_znam.Parameters.AddWithValue("Chisl_Znam", "Знаменатель");
                    //Вывод занятий в зависимости от числителя или знаменателя
                    if (zam.ExecuteScalar() != null)
                    {
                        zan = zam.ExecuteScalar().ToString();
                    }
                    else if (osn_rasp_znam.ExecuteScalar() != null && chislznam == "Знаменатель")
                    {
                        zan = osn_rasp_znam.ExecuteScalar().ToString();
                    }
                    else if (osn_rasp.ExecuteScalar() != null)
                    {
                        zan = osn_rasp.ExecuteScalar().ToString();
                    }
                    else
                    {
                        zan = "Нет";
                    }
                    length = 0;
                    zan_izm = "";
                    foreach (char c in zan)
                    {
                        length++;
                        zan_izm += c.ToString();
                        if (c.ToString() == " " && length > 30 && length < 40)
                        {
                            zan_izm += Environment.NewLine;
                        }
                        
                    }

                    labels[i].Text = zan_izm;
                }
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            SqlCommand c_z = new SqlCommand("SELECT Chisl_Znam FROM Chisl_Znam WHERE Po>=@date AND S<=@date", Connections.sqlConnection); /*Выборка числителя/занаменателя*/
            c_z.Parameters.AddWithValue("date", Convert.ToDateTime(dateTimePicker1.Value).Date);
            try
            {
                chislznam = c_z.ExecuteScalar().ToString();
            }
            catch
            {
                check = true;
            }
            indexday = Convert.ToInt32(dateTimePicker1.Value.DayOfWeek);
            if (check == false && comboBox1.Text != "")
            {
                for (int i = 0; i < 6; i++)
                {
                    SqlCommand osn_rasp = new SqlCommand("SELECT Name_Zan FROM Osn_Rasp WHERE Day_of_Week=@Day_of_Week AND Chas=@Chas AND Name_Grup=@Name_Grup AND Chisl_Znam=@Chisl_Znam", Connections.sqlConnection);
                    osn_rasp.Parameters.AddWithValue("Day_of_Week", indexday);
                    osn_rasp.Parameters.AddWithValue("Chas", chas[i]);
                    osn_rasp.Parameters.AddWithValue("Name_Grup", comboBox1.Text);
                    osn_rasp.Parameters.AddWithValue("Chisl_Znam", "Числитель");

                    SqlCommand zam = new SqlCommand("SELECT Name_Zan FROM Zameni WHERE Name_Group=@Name_Group AND Date=@Date AND Chas=@Chas", Connections.sqlConnection);
                    zam.Parameters.AddWithValue("Name_Group", comboBox1.Text);
                    zam.Parameters.AddWithValue("Date", Convert.ToDateTime(dateTimePicker1.Value).Date);
                    zam.Parameters.AddWithValue("Chas", chas[i]);

                    SqlCommand osn_rasp_znam = new SqlCommand("SELECT Name_Zan FROM Osn_Rasp WHERE Day_of_Week=@Day_of_Week AND Chas=@Chas AND Name_Grup=@Name_Grup AND Chisl_Znam=@Chisl_Znam", Connections.sqlConnection);
                    osn_rasp_znam.Parameters.AddWithValue("Day_of_Week", indexday);
                    osn_rasp_znam.Parameters.AddWithValue("Chas", chas[i]);
                    osn_rasp_znam.Parameters.AddWithValue("Name_Grup", comboBox1.Text);
                    osn_rasp_znam.Parameters.AddWithValue("Chisl_Znam", "Знаменатель");
                    //Вывод занятий в зависимости от числителя или знаменателя
                    if (zam.ExecuteScalar() != null)
                    {
                        zan = zam.ExecuteScalar().ToString();
                    }
                    else if (osn_rasp_znam.ExecuteScalar() != null && chislznam == "Знаменатель")
                    {
                        zan = osn_rasp_znam.ExecuteScalar().ToString();
                    }
                    else if (osn_rasp.ExecuteScalar() != null)
                    {
                        zan = osn_rasp.ExecuteScalar().ToString();
                    }
                    else
                    {
                        zan = "Нет";
                    }

                    length = 0;
                    zan_izm = "";
                    foreach (char c in zan)
                    {
                        length++;
                        zan_izm += c.ToString();
                        if (c.ToString() == " " && length > 36 && length < 40)
                        {
                            zan_izm += Environment.NewLine;
                        }

                    }

                    labels[i].Text = zan_izm;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Connections.Connect();
            if(Connections.checkConnect == true)
            {
                comboBox1.Enabled = true;
                dateTimePicker1.Enabled = true;
                button1.Enabled = true;

                SqlCommand groups = new SqlCommand("SELECT * FROM Groups", Connections.sqlConnection); /*Добавление групп в comboBox*/
                SqlDataReader readerGroup = groups.ExecuteReader();
                while (readerGroup.Read())
                {
                    comboBox1.Items.Add(readerGroup["Group_Name"]);
                }
                readerGroup.Close();

                indexday = Convert.ToInt32(dateTimePicker1.Value.DayOfWeek);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            User_Log.Nick = "";
            User_Log.Password = "";
            User_Log.Rules = "";
            User_Log.Mail = "";
            User_Log.Active_Mail = "";
            this.Hide();
            Form3 form3 = new Form3();
            form3.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form8 form8 = new Form8();
            form8.Show();
        }

        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
