﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Replacements
{
    public partial class Form4 : Form
    {
        //Copyright(C) 2019 Евгений Петриев
        //This program is free software: you can redistribute it and/or modify
        //it under the terms of the GNU General Public License as published by
        //the Free Software Foundation, either version 3 of the License, or
        //(at your option) any later version.

        //This program is distributed in the hope that it will be useful,
        //but WITHOUT ANY WARRANTY; without even the implied warranty of
        //MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
        //GNU General Public License for more details.

        //You should have received a copy of the GNU General Public License
        //along with this program.If not, see<http://www.gnu.org/licenses/>.

        public string[] chislznam = new string[2];
        string[] chas = new string[6];
        string[] daysofweek = new string[7];
        int indexday = 0;
        ComboBox[] comboBoxes = new ComboBox[12];
        bool[] check = new bool[12];

        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            comboBoxes[0] = comboBox3;
            comboBoxes[1] = comboBox4;
            comboBoxes[2] = comboBox5;
            comboBoxes[3] = comboBox6;
            comboBoxes[4] = comboBox7;
            comboBoxes[5] = comboBox8;
            comboBoxes[6] = comboBox9;
            comboBoxes[7] = comboBox10;
            comboBoxes[8] = comboBox11;
            comboBoxes[9] = comboBox12;
            comboBoxes[10] = comboBox13;
            comboBoxes[11] = comboBox14;

            comboBox1.Items.Clear();

            SqlCommand groups = new SqlCommand("SELECT * FROM Groups", Connections.sqlConnection); /*Добавление групп в comboBox*/
            SqlDataReader readerGroup = groups.ExecuteReader();
            while (readerGroup.Read())
            {
                comboBox1.Items.Add(readerGroup["Group_Name"]);
            }
            readerGroup.Close();

            chislznam[0] = "Числитель";
            chislznam[1] = "Знаменатель";

            chas[0] = "1-2";
            chas[1] = "3-4";
            chas[2] = "5-6";
            chas[3] = "7-8";
            chas[4] = "9-10";
            chas[5] = "11-12";

            daysofweek[1] = "Понедельник";
            daysofweek[2] = "Вторник";
            daysofweek[3] = "Среда";
            daysofweek[4] = "Четверг";
            daysofweek[5] = "Пятница";
            daysofweek[6] = "Суббота";
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < 12; i++)
            {
                check[i] = false;
            }
            if (comboBox1.Text != "" && comboBox2.Text != "")
            {
                int c = 0;
                for (int i = 1; i < 7; i++)
                {
                    if (daysofweek[i] == comboBox2.Text)
                    {
                        indexday = i;
                    }
                }
                for (int i = 0; i < 6; i++)
                {
                    for (int j = 0; j < 2; j++)
                    {
                        SqlCommand zan = new SqlCommand("SELECT * FROM Osn_rasp WHERE Day_Of_Week=@Day_Of_Week and Name_Grup=@Name_Grup and Chas=@Chas and Chisl_Znam=@Chisl_Znam", Connections.sqlConnection); /*Выборка занятий*/
                        zan.Parameters.AddWithValue("Day_Of_Week", indexday);
                        zan.Parameters.AddWithValue("Name_Grup", comboBox1.Text);
                        zan.Parameters.AddWithValue("Chas", chas[i]);
                        zan.Parameters.AddWithValue("Chisl_Znam", chislznam[j]);

                        if (zan.ExecuteScalar() != null)
                        {
                            check[c] = true;
                            SqlDataReader zanreader = zan.ExecuteReader();
                            while (zanreader.Read())
                            {
                                string zanyatie = string.Empty;
                                zanyatie += zanreader["Name_Zan"];
                                comboBoxes[c].Text = zanyatie;
                            }
                            zanreader.Close();
                        }
                        else
                        {
                            comboBoxes[c].Text = "Нет";
                        }
                        c++;
                    }
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < 12; i++)
            {
                check[i] = false;
            }
            SqlCommand zanyatiya = new SqlCommand("SELECT * FROM Zanyatiya WHERE Name_Group=@Name_Group OR Name_Group=@Name_Group_Null", Connections.sqlConnection); 
            zanyatiya.Parameters.AddWithValue("Name_Group", comboBox1.Text);
            zanyatiya.Parameters.AddWithValue("Name_Group_Null", "All");
            SqlDataReader readerZan = zanyatiya.ExecuteReader();

            for (int i = 0; i < 12; i++)
            {
                comboBoxes[i].Items.Clear();
            }

            while (readerZan.Read())
            {
                string zan = string.Empty;
                zan += readerZan["Name_Zan"];
                for (int i = 0; i < 12; i++)
                {
                    comboBoxes[i].Items.Add(zan);
                }
            }
            readerZan.Close();

            if (comboBox2.Text != "" && comboBox1.Text != "")
            {
                int c = 0;
                for (int i = 1; i < 7; i++)
                {
                    if (daysofweek[i] == comboBox2.Text)
                    {
                        indexday = i;
                    }
                }
                for (int i = 0; i < 6; i++)
                {
                    for (int j = 0; j < 2; j++)
                    {
                        SqlCommand zan = new SqlCommand("SELECT * FROM Osn_rasp WHERE Day_Of_Week=@Day_Of_Week and Name_Grup=@Name_Grup and Chas=@Chas and Chisl_Znam=@Chisl_Znam", Connections.sqlConnection); /*Выборка занятий*/
                        zan.Parameters.AddWithValue("Day_Of_Week", indexday);
                        zan.Parameters.AddWithValue("Name_Grup", comboBox1.Text);
                        zan.Parameters.AddWithValue("Chas", chas[i]);
                        zan.Parameters.AddWithValue("Chisl_Znam", chislznam[j]);

                        if (zan.ExecuteScalar() != null)
                        {
                            check[c] = true;
                            SqlDataReader zanreader = zan.ExecuteReader();
                            while (zanreader.Read())
                            {
                                string zanyatie = string.Empty;
                                zanyatie += zanreader["Name_Zan"];
                                comboBoxes[c].Text = zanyatie;
                            }
                            zanreader.Close();
                        }
                        else
                        {
                            comboBoxes[c].Text = "Нет";
                        }
                        c++;
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Добавление и изменение основного расписания
            int c = 0;
            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    if (check[c] == true)
                    {
                        SqlCommand updrasp = new SqlCommand("UPDATE Osn_Rasp SET Name_Zan=@Name_Zan WHERE Day_Of_Week=@Day_Of_Week and Name_Grup=@Name_Grup and Chas=@Chas and Chisl_Znam=@Chisl_Znam", Connections.sqlConnection);
                        updrasp.Parameters.AddWithValue("Name_Zan", comboBoxes[c].Text);
                        updrasp.Parameters.AddWithValue("Day_Of_Week", indexday);
                        updrasp.Parameters.AddWithValue("Name_Grup", comboBox1.Text);
                        updrasp.Parameters.AddWithValue("Chas", chas[i]);
                        updrasp.Parameters.AddWithValue("Chisl_Znam", chislznam[j]);
                        updrasp.ExecuteNonQuery();
                    }
                    else if (comboBoxes[c].Text != "Нет")
                    {
                        SqlCommand insrasp = new SqlCommand("INSERT INTO Osn_Rasp (Name_Zan, Day_Of_Week, Name_Grup, Chas, Chisl_Znam) VALUES (@Name_Zan, @Day_Of_Week, @Name_Grup, @Chas, @Chisl_Znam)", Connections.sqlConnection);
                        insrasp.Parameters.AddWithValue("Name_Zan", comboBoxes[c].Text);
                        insrasp.Parameters.AddWithValue("Day_Of_Week", indexday);
                        insrasp.Parameters.AddWithValue("Name_Grup", comboBox1.Text);
                        insrasp.Parameters.AddWithValue("Chas", chas[i]);
                        insrasp.Parameters.AddWithValue("Chisl_Znam", chislznam[j]);
                        insrasp.ExecuteNonQuery();
                    }
                    c++;
                }
            }
            MessageBox.Show("Изменения были успешно внесены", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form6 f6 = new Form6();
            f6.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();
            form7.ShowDialog();
        }
    }
}

