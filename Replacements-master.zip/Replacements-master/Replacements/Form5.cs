﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Replacements
{
    public partial class Form5 : Form
    {
        //Copyright(C) 2019 Евгений Петриев
        //This program is free software: you can redistribute it and/or modify
        //it under the terms of the GNU General Public License as published by
        //the Free Software Foundation, either version 3 of the License, or
        //(at your option) any later version.

        //This program is distributed in the hope that it will be useful,
        //but WITHOUT ANY WARRANTY; without even the implied warranty of
        //MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
        //GNU General Public License for more details.

        //You should have received a copy of the GNU General Public License
        //along with this program.If not, see<http://www.gnu.org/licenses/>.

        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_FormClosing(object sender, FormClosingEventArgs e)
        {

        }

        private void usersBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.usersBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.zamenyDataSet1);

        }

        private void Form5_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "u0686611_ReplacementsDataSet.Users". При необходимости она может быть перемещена или удалена.
            this.usersTableAdapter1.Fill(this.u0686611_ReplacementsDataSet.Users);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "u0686611_ReplacementsDataSet.Users". При необходимости она может быть перемещена или удалена.
            this.usersTableAdapter1.Fill(this.u0686611_ReplacementsDataSet.Users);

        }

        private void button4_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Form10 form10 = new Form10();
            form10.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            int a = usersDataGridView.SelectedCells[0].RowIndex;
            Info.info = Convert.ToString(usersDataGridView.Rows[a].Cells[0].Value);

            Form11 form11 = new Form11();
            form11.ShowDialog();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            int a = usersDataGridView.SelectedCells[0].RowIndex;
            string logDel = Convert.ToString(usersDataGridView.Rows[a].Cells[0].Value);

            DialogResult result = MessageBox.Show("Вы уверенны, что хотите удалить пользователя?", "Подтвердите действие", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                SqlCommand delUser = new SqlCommand("DELETE FROM Users WHERE Login=@Login", Connections.sqlConnection);
                delUser.Parameters.AddWithValue("Login", logDel);
                delUser.ExecuteNonQuery();

                this.usersTableAdapter.Fill(this.zamenyDataSet1.Users);
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            this.usersTableAdapter1.Fill(this.u0686611_ReplacementsDataSet.Users);
        }
    }
}
