﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Replacements
{
    public partial class Form6 : Form
    {
        //Copyright(C) 2019 Евгений Петриев
        //This program is free software: you can redistribute it and/or modify
        //it under the terms of the GNU General Public License as published by
        //the Free Software Foundation, either version 3 of the License, or
        //(at your option) any later version.

        //This program is distributed in the hope that it will be useful,
        //but WITHOUT ANY WARRANTY; without even the implied warranty of
        //MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
        //GNU General Public License for more details.

        //You should have received a copy of the GNU General Public License
        //along with this program.If not, see<http://www.gnu.org/licenses/>.

        string[] chas = new string[6];
        ComboBox[] comboBoxes = new ComboBox[6];
        string chislznam = string.Empty;
        int indexday = 0;

        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            chas[0] = "1-2";
            chas[1] = "3-4";
            chas[2] = "5-6";
            chas[3] = "7-8";
            chas[4] = "9-10";
            chas[5] = "11-12";

            comboBoxes[0] = comboBox3;
            comboBoxes[1] = comboBox4;
            comboBoxes[2] = comboBox5;
            comboBoxes[3] = comboBox6;
            comboBoxes[4] = comboBox7;
            comboBoxes[5] = comboBox8;

            SqlCommand groups = new SqlCommand("SELECT * FROM Groups", Connections.sqlConnection);
            SqlDataReader readerGroup = groups.ExecuteReader();
            while (readerGroup.Read())
            {
                comboBox1.Items.Add(readerGroup["Group_Name"]);
            }
            readerGroup.Close();


        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            bool check = false;
            SqlCommand c_z = new SqlCommand("SELECT Chisl_Znam FROM Chisl_Znam WHERE Po>=@date AND S<=@date", Connections.sqlConnection); /*Выборка числителя/занаменателя*/

            SqlCommand zanyatiya = new SqlCommand("SELECT * FROM Zanyatiya WHERE Name_Group=@Name_Group OR Name_Group='All'", Connections.sqlConnection);
            zanyatiya.Parameters.AddWithValue("Name_Group", comboBox1.Text);

            SqlDataReader readerZan = zanyatiya.ExecuteReader();

            for (int i = 0; i < 6; i++)
            {
                comboBoxes[i].Items.Clear();
            }

            while (readerZan.Read())
            {
                string zan = string.Empty;
                zan += readerZan["Name_Zan"];
                for (int i = 0; i < 6; i++)
                {
                    comboBoxes[i].Items.Add(zan);
                }
            }
            readerZan.Close();

            c_z.Parameters.AddWithValue("date",Convert.ToDateTime(dateTimePicker1.Value).Date);
            try
            {
                chislznam = c_z.ExecuteScalar().ToString();
            }
            catch
            {
                check = true;
            }
            indexday = Convert.ToInt32(dateTimePicker1.Value.DayOfWeek);
            if (check == false && comboBox1.Text != "")
            {
                for (int i = 0; i < 6; i++)
                {
                    SqlCommand osn_rasp = new SqlCommand("SELECT Name_Zan FROM Osn_Rasp WHERE Day_of_Week=@Day_of_Week AND Chas=@Chas AND Name_Grup=@Name_Grup AND Chisl_Znam=@Chisl_Znam", Connections.sqlConnection);
                    osn_rasp.Parameters.AddWithValue("Day_of_Week", indexday);
                    osn_rasp.Parameters.AddWithValue("Chas", chas[i]);
                    osn_rasp.Parameters.AddWithValue("Name_Grup", comboBox1.Text);
                    osn_rasp.Parameters.AddWithValue("Chisl_Znam", "Числитель");

                    SqlCommand zam = new SqlCommand("SELECT Name_Zan FROM Zameni WHERE Name_Group=@Name_Group AND Date=@Date AND Chas=@Chas", Connections.sqlConnection);
                    zam.Parameters.AddWithValue("Name_Group", comboBox1.Text);
                    zam.Parameters.AddWithValue("Date", Convert.ToDateTime(dateTimePicker1.Value).Date);
                    zam.Parameters.AddWithValue("Chas", chas[i]);

                    SqlCommand osn_rasp_znam = new SqlCommand("SELECT Name_Zan FROM Osn_Rasp WHERE Day_of_Week=@Day_of_Week AND Chas=@Chas AND Name_Grup=@Name_Grup AND Chisl_Znam=@Chisl_Znam", Connections.sqlConnection);
                    osn_rasp_znam.Parameters.AddWithValue("Day_of_Week", indexday);
                    osn_rasp_znam.Parameters.AddWithValue("Chas", chas[i]);
                    osn_rasp_znam.Parameters.AddWithValue("Name_Grup", comboBox1.Text);
                    osn_rasp_znam.Parameters.AddWithValue("Chisl_Znam", "Знаменатель");
                    //Вывод занятий в зависимости от числителя или знаменателя
                    if (zam.ExecuteScalar() != null)
                    {
                        comboBoxes[i].Text = zam.ExecuteScalar().ToString();
                    }
                    else if (osn_rasp_znam.ExecuteScalar() != null && chislznam == "Знаменатель")
                    {
                        comboBoxes[i].Text = osn_rasp_znam.ExecuteScalar().ToString();
                    }
                    else if (osn_rasp.ExecuteScalar() != null)
                    {
                        comboBoxes[i].Text = osn_rasp.ExecuteScalar().ToString();
                    }
                    else
                    {
                        comboBoxes[i].Text = "Нет";
                    }
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Добавление/изменение замен в зависимости от того есть-ли в БД расписание замен на этот день
            for(int i = 0; i < 6; i++){
                SqlCommand osn_rasp = new SqlCommand("SELECT Name_Zan FROM Osn_Rasp WHERE Day_of_Week=@Day_of_Week AND Chas=@Chas AND Name_Grup=@Name_Grup AND Chisl_Znam=@Chisl_Znam", Connections.sqlConnection);
                osn_rasp.Parameters.AddWithValue("Day_of_Week", indexday);
                osn_rasp.Parameters.AddWithValue("Chas", chas[i]);
                osn_rasp.Parameters.AddWithValue("Name_Grup", comboBox1.Text);
                osn_rasp.Parameters.AddWithValue("Chisl_Znam", chislznam);

                SqlCommand zamen = new SqlCommand("SELECT Name_Zan FROM Zameni WHERE Name_Group=@Name_Group AND Date=@Date AND Chas=@Chas", Connections.sqlConnection);
                zamen.Parameters.AddWithValue("Name_Group", comboBox1.Text);
                zamen.Parameters.AddWithValue("Date", Convert.ToDateTime(dateTimePicker1.Value).Date);
                zamen.Parameters.AddWithValue("Chas", chas[i]);

                if(osn_rasp.ExecuteScalar() == null)
                {
                    if (zamen.ExecuteScalar() == null)
                    {
                        SqlCommand insZam = new SqlCommand("INSERT INTO Zameni (Name_Zan,Name_Group,Date,Chas) VALUES (@Name_Zan,@Name_Group,@Date,@Chas)", Connections.sqlConnection);
                        insZam.Parameters.AddWithValue("Name_Zan", comboBoxes[i].Text);
                        insZam.Parameters.AddWithValue("Name_Group", comboBox1.Text);
                        insZam.Parameters.AddWithValue("Date", dateTimePicker1.Value);
                        insZam.Parameters.AddWithValue("Chas", chas[i]);
                        insZam.ExecuteNonQuery();
                    }
                    else
                    {
                        SqlCommand updZam = new SqlCommand("UPDATE Zameni SET Name_Zan=@Name_Zan WHERE Name_Group=@Name_Group AND Date=@Date AND Chas=@Chas", Connections.sqlConnection);
                        updZam.Parameters.AddWithValue("Name_Zan", comboBoxes[i].Text);
                        updZam.Parameters.AddWithValue("Name_Group", comboBox1.Text);
                        updZam.Parameters.AddWithValue("Date", Convert.ToDateTime(dateTimePicker1.Value).Date);
                        updZam.Parameters.AddWithValue("Chas", chas[i]);
                        updZam.ExecuteNonQuery();
                    }
                }
                else if (comboBoxes[i].Text != osn_rasp.ExecuteScalar().ToString())
                {
                    if (zamen.ExecuteScalar() == null)
                    {
                        SqlCommand insZam = new SqlCommand("INSERT INTO Zameni (Name_Zan,Name_Group,Date,Chas) VALUES (@Name_Zan,@Name_Group,@Date,@Chas)", Connections.sqlConnection);
                        insZam.Parameters.AddWithValue("Name_Zan", comboBoxes[i].Text);
                        insZam.Parameters.AddWithValue("Name_Group", comboBox1.Text);
                        insZam.Parameters.AddWithValue("Date", dateTimePicker1.Value);
                        insZam.Parameters.AddWithValue("Chas", chas[i]);
                        insZam.ExecuteNonQuery();
                    }
                    else
                    {
                        SqlCommand updZam = new SqlCommand("UPDATE Zameni SET Name_Zan=@Name_Zan WHERE Name_Group=@Name_Group AND Date=@Date AND Chas=@Chas", Connections.sqlConnection);
                        updZam.Parameters.AddWithValue("Name_Zan", comboBoxes[i].Text);
                        updZam.Parameters.AddWithValue("Name_Group", comboBox1.Text);
                        updZam.Parameters.AddWithValue("Date", Convert.ToDateTime(dateTimePicker1.Value).Date);
                        updZam.Parameters.AddWithValue("Chas", chas[i]);
                        updZam.ExecuteNonQuery();
                    }
                }
               
            }
            MessageBox.Show("Изменения были успешно внесены", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool check = false;
            SqlCommand c_z = new SqlCommand("SELECT Chisl_Znam FROM Chisl_Znam WHERE Po>=@date AND S<=@date", Connections.sqlConnection);

            SqlCommand zanyatiya = new SqlCommand("SELECT * FROM Zanyatiya WHERE Name_Group=@Name_Group OR Name_Group='All'", Connections.sqlConnection);
            zanyatiya.Parameters.AddWithValue("Name_Group", comboBox1.Text);

            SqlDataReader readerZan = zanyatiya.ExecuteReader();

            for (int i = 0; i < 6; i++)
            {
                comboBoxes[i].Items.Clear();
            }

            while (readerZan.Read())
            {
                string zan = string.Empty;
                zan += readerZan["Name_Zan"];
                for (int i = 0; i < 6; i++)
                {
                    comboBoxes[i].Items.Add(zan);
                }
            }
            readerZan.Close();

            c_z.Parameters.AddWithValue("date", dateTimePicker1.Value);
            try
            {
                chislznam = c_z.ExecuteScalar().ToString();
            }
            catch
            {
                check = true;
            }
            indexday = Convert.ToInt32(dateTimePicker1.Value.DayOfWeek);
            if (check == false && comboBox1.Text != "")
            { 
                for (int i = 0; i < 6; i++)
                {
                    SqlCommand osn_rasp = new SqlCommand("SELECT Name_Zan FROM Osn_Rasp WHERE Day_of_Week=@Day_of_Week AND Chas=@Chas AND Name_Grup=@Name_Grup AND Chisl_Znam=@Chisl_Znam", Connections.sqlConnection);
                    osn_rasp.Parameters.AddWithValue("Day_of_Week", indexday);
                    osn_rasp.Parameters.AddWithValue("Chas", chas[i]);
                    osn_rasp.Parameters.AddWithValue("Name_Grup", comboBox1.Text);
                    osn_rasp.Parameters.AddWithValue("Chisl_Znam", "Числитель");

                    SqlCommand zam = new SqlCommand("SELECT Name_Zan FROM Zameni WHERE Name_Group=@Name_Group AND Date=@Date AND Chas=@Chas", Connections.sqlConnection);
                    zam.Parameters.AddWithValue("Name_Group", comboBox1.Text);
                    zam.Parameters.AddWithValue("Date",Convert.ToDateTime(dateTimePicker1.Value).Date);
                    zam.Parameters.AddWithValue("Chas", chas[i]);

                    SqlCommand osn_rasp_znam = new SqlCommand("SELECT Name_Zan FROM Osn_Rasp WHERE Day_of_Week=@Day_of_Week AND Chas=@Chas AND Name_Grup=@Name_Grup AND Chisl_Znam=@Chisl_Znam", Connections.sqlConnection);
                    osn_rasp_znam.Parameters.AddWithValue("Day_of_Week", indexday);
                    osn_rasp_znam.Parameters.AddWithValue("Chas", chas[i]);
                    osn_rasp_znam.Parameters.AddWithValue("Name_Grup", comboBox1.Text);
                    osn_rasp_znam.Parameters.AddWithValue("Chisl_Znam", "Знаменатель");

                    if (zam.ExecuteScalar() != null)
                    {
                        comboBoxes[i].Text = zam.ExecuteScalar().ToString();
                    }
                    else if(osn_rasp_znam.ExecuteScalar() != null && chislznam == "Знаменатель")
                    {
                        comboBoxes[i].Text = osn_rasp_znam.ExecuteScalar().ToString();
                    }
                    else if (osn_rasp.ExecuteScalar() != null)
                    {
                        comboBoxes[i].Text = osn_rasp.ExecuteScalar().ToString();
                    }
                    else
                    {
                        comboBoxes[i].Text = "Нет";
                    }
                }
                
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Удаление из БД значений в зависимости от даты
            DialogResult result = MessageBox.Show("Подтверждение", "Вы уверены, что хотите очистить значения?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                SqlCommand delIzm = new SqlCommand("DELETE FROM Zameni WHERE Name_Group=@Name_Group AND Date=@Date", Connections.sqlConnection);
                delIzm.Parameters.AddWithValue("Name_Group", comboBox1.Text);
                delIzm.Parameters.AddWithValue("Date", Convert.ToDateTime(dateTimePicker1.Value).Date);
                delIzm.ExecuteNonQuery();

                for(int i = 0; i < 6; i++)
                {
                    
                    SqlCommand osn_rasp = new SqlCommand("SELECT Name_Zan FROM Osn_Rasp WHERE Day_of_Week=@Day_of_Week AND Chas=@Chas AND Name_Grup=@Name_Grup AND Chisl_Znam=@Chisl_Znam", Connections.sqlConnection);
                    osn_rasp.Parameters.AddWithValue("Day_of_Week", indexday);
                    osn_rasp.Parameters.AddWithValue("Chas", chas[i]);
                    osn_rasp.Parameters.AddWithValue("Name_Grup", comboBox1.Text);
                    osn_rasp.Parameters.AddWithValue("Chisl_Znam", "Числитель");

                    SqlCommand osn_rasp_znam = new SqlCommand("SELECT Name_Zan FROM Osn_Rasp WHERE Day_of_Week=@Day_of_Week AND Chas=@Chas AND Name_Grup=@Name_Grup AND Chisl_Znam=@Chisl_Znam", Connections.sqlConnection);
                    osn_rasp_znam.Parameters.AddWithValue("Day_of_Week", indexday);
                    osn_rasp_znam.Parameters.AddWithValue("Chas", chas[i]);
                    osn_rasp_znam.Parameters.AddWithValue("Name_Grup", comboBox1.Text);
                    osn_rasp_znam.Parameters.AddWithValue("Chisl_Znam", "Знаменатель");

                    if(osn_rasp_znam.ExecuteScalar() != null && chislznam == "Знаменатель")
                    {
                        comboBoxes[i].Text = osn_rasp_znam.ExecuteScalar().ToString();
                    }
                    else if (osn_rasp.ExecuteScalar() != null)
                    {
                        comboBoxes[i].Text = osn_rasp.ExecuteScalar().ToString();
                    }
                    else
                    {
                        comboBoxes[i].Text = "Нет";
                    }
                }
            }
        }
    }
}
