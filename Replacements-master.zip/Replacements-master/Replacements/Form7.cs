﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Replacements
{
    public partial class Form7 : Form
    {
        //Copyright(C) 2019 Евгений Петриев
        //This program is free software: you can redistribute it and/or modify
        //it under the terms of the GNU General Public License as published by
        //the Free Software Foundation, either version 3 of the License, or
        //(at your option) any later version.

        //This program is distributed in the hope that it will be useful,
        //but WITHOUT ANY WARRANTY; without even the implied warranty of
        //MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
        //GNU General Public License for more details.

        //You should have received a copy of the GNU General Public License
        //along with this program.If not, see<http://www.gnu.org/licenses/>.
        public Form7()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "u0686611_ReplacementsDataSet.Chisl_Znam". При необходимости она может быть перемещена или удалена.
            this.chisl_ZnamTableAdapter1.Fill(this.u0686611_ReplacementsDataSet.Chisl_Znam);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "u0686611_ReplacementsDataSet.Zanyatiya". При необходимости она может быть перемещена или удалена.
            this.zanyatiyaTableAdapter1.Fill(this.u0686611_ReplacementsDataSet.Zanyatiya);

            comboBox1.Items.Clear();
            SqlCommand groups = new SqlCommand("SELECT Group_Name FROM Groups", Connections.sqlConnection);

            SqlDataReader groupReader = groups.ExecuteReader();
            while (groupReader.Read())
            {
                string group = string.Empty;
                group += groupReader["Group_Name"];
                comboBox1.Items.Add(group);
            }
            groupReader.Close();

        }

        private void zanyatiyaBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.zanyatiyaBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.zamenyDataSet1);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string group = string.Empty;
            if(textBox1.Text != "" && (comboBox1.Text != "" || checkBox1.Checked == true))
            {
                SqlCommand insZan = new SqlCommand("INSERT INTO Zanyatiya (Name_Zan, Name_Group) VALUES (@Name_Zan, @Name_Group)", Connections.sqlConnection);
                insZan.Parameters.AddWithValue("Name_Zan", textBox1.Text);

                if(checkBox1.Checked == true)
                {
                    group = "All";
                }
                else
                {
                    group = comboBox1.Text;
                }
                insZan.Parameters.AddWithValue("Name_Group", group);
                try
                {
                    insZan.ExecuteNonQuery();
                    textBox1.Text = "";
                }
                catch
                {
                    MessageBox.Show("Данное занятие уже есть", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBox1.Text = "";
                }
                this.zanyatiyaTableAdapter1.Fill(this.u0686611_ReplacementsDataSet.Zanyatiya);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                comboBox1.Enabled = false;
                comboBox1.Text = "";
            }
            else
            {
                comboBox1.Enabled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int a = zanyatiyaDataGridView.SelectedCells[0].RowIndex;
            string id_del = Convert.ToString(zanyatiyaDataGridView.Rows[a].Cells[0].Value);

            SqlCommand delZan = new SqlCommand("DELETE FROM Zanyatiya WHERE Name_Zan=@Name_Zan", Connections.sqlConnection);
            delZan.Parameters.AddWithValue("Name_Zan", id_del);
            delZan.ExecuteNonQuery();
            this.zanyatiyaTableAdapter.Fill(this.zamenyDataSet1.Zanyatiya);

            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (comboBox2.Text != "" && (Convert.ToDateTime(dateTimePicker1.Value).Date <= Convert.ToDateTime(dateTimePicker2.Value).Date))
            {
                DateTime date = dateTimePicker1.Value;
                DateTime date1 = dateTimePicker1.Value;
                DateTime date2 = dateTimePicker2.Value;
                DateTime dateNach;
                DateTime dateKon;
                int maxDay;
                int day = date.Day;
                string chislznam = comboBox2.Text;
                dateNach = date1;

                SqlCommand delChislZnam = new SqlCommand("DELETE FROM Chisl_Znam", Connections.sqlConnection);
                delChislZnam.ExecuteNonQuery();
                for (int y = date1.Year; y <= date1.Year; y++)
                {
                    for (int i = date1.Month; i <= date2.Month; i++)
                    {
                        Days.DaysInWeek(i, date1.Year, out maxDay);
                        if (date2.Month == i)
                        {
                            maxDay = date2.Day;
                        }

                        for (int j = day; j <= maxDay; j++)
                        {
                            date = new DateTime(y, i, j);
                            if (Convert.ToInt32(date.DayOfWeek) == 0)
                            {
                                dateKon = date;

                                SqlCommand insChisZnam = new SqlCommand("INSERT INTO Chisl_Znam (Chisl_Znam, S, Po) VALUES (@Chisl_Znam, @S, @Po)", Connections.sqlConnection);
                                insChisZnam.Parameters.AddWithValue("Chisl_Znam", chislznam);
                                insChisZnam.Parameters.AddWithValue("S", dateNach);
                                insChisZnam.Parameters.AddWithValue("Po", dateKon);
                                insChisZnam.ExecuteNonQuery();
                                if (chislznam == "Числитель")
                                {
                                    chislznam = "Знаменатель";
                                }
                                else
                                {
                                    chislznam = "Числитель";
                                }
                            }
                            if (Convert.ToInt32(date.DayOfWeek) == 1)
                            {
                                dateNach = date;
                            }

                        }
                        day = 1;
                    }
                }
                this.chisl_ZnamTableAdapter1.Fill(this.u0686611_ReplacementsDataSet.Chisl_Znam);
            }
            else
            {
                MessageBox.Show("Поля заполнены не корректно", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
