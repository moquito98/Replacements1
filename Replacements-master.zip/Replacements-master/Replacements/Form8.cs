﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Replacements
{
    public partial class Form8 : Form
    {
        //Copyright(C) 2019 Евгений Петриев
        //This program is free software: you can redistribute it and/or modify
        //it under the terms of the GNU General Public License as published by
        //the Free Software Foundation, either version 3 of the License, or
        //(at your option) any later version.

        //This program is distributed in the hope that it will be useful,
        //but WITHOUT ANY WARRANTY; without even the implied warranty of
        //MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
        //GNU General Public License for more details.

        //You should have received a copy of the GNU General Public License
        //along with this program.If not, see<http://www.gnu.org/licenses/>.
        public Form8()
        {
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            label1.Text = "Логин: " + User_Log.Nick;
            label2.Text = "E-Mail: " + User_Log.Mail;
            if (User_Log.Active_Mail == "Non active")
            {
                label3.Visible = true;
                linkLabel1.Visible = true;
            }
            else
            {
                label3.Visible = false;
                linkLabel1.Visible = false;
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form14 form14 = new Form14();
            form14.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form15 form15 = new Form15();
            form15.Show();
        }
    }
}
