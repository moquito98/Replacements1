﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Replacements
{
    class TimerOtpr
    {
        //Copyright(C) 2019 Евгений Петриев
        //This program is free software: you can redistribute it and/or modify
        //it under the terms of the GNU General Public License as published by
        //the Free Software Foundation, either version 3 of the License, or
        //(at your option) any later version.

        //This program is distributed in the hope that it will be useful,
        //but WITHOUT ANY WARRANTY; without even the implied warranty of
        //MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
        //GNU General Public License for more details.

        //You should have received a copy of the GNU General Public License
        //along with this program.If not, see<http://www.gnu.org/licenses/>.

        public static void StartTimer(Label label, Timer timer, int s, int m, Button button)
        {
            label.Visible = true;
            timer.Interval = 1000;
            timer.Tick += new System.EventHandler(timer1_Tick);
            timer.Start();
            void timer1_Tick(object sender, EventArgs e)
            {
                if (m != 0 || s != 0)
                {
                    if (s == 0)
                    {
                        s = 59;
                        m--;
                    }
                    else
                    {
                        s--;
                    }
                    if (s < 10)
                    {
                        label.Text = "Повторный запрос через " + m.ToString() + ":"+"0" + s.ToString();
                    }
                    else
                    {
                        label.Text = "Повторный запрос через " + m.ToString() + ":" + s.ToString();
                    }
                }
                else
                {
                    timer.Stop();
                    label.Visible = false;
                    button.Enabled = true;
                }
            }
        }
    }
}
